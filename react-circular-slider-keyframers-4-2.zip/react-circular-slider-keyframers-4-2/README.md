# React Circular Slider | @keyframers 4.2

A Pen created on CodePen.io. Original URL: [https://codepen.io/team/keyframers/pen/BaWROOw](https://codepen.io/team/keyframers/pen/BaWROOw).

David Khourshid & Stephen Shaw build a fancy circular React slider from scratch using CSS Variables!

🎥  Video: https://youtu.be/sFJa1ThZReA
💡 Inspiration: https://dribbble.com/shots/15713715-Samaritan-Stories-of-Impact-slider
💻 Code: (coming soon...)

Like what we're doing? Support @keyframers so we can keep live coding awesome animations!

* Like & subscribe on YouTube at https://youtube.com/keyframers
* Buy web dev shirts, stickers & more at https://keyframe.rs/merch
* Follow & tweet us at https://twitter.com/keyframers
* Support us on Patreon at https://patreon.com/keyframers