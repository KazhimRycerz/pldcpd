# What do you have to be scared of?

A Pen created on CodePen.io. Original URL: [https://codepen.io/ltackett/pen/AeRdXV](https://codepen.io/ltackett/pen/AeRdXV).

I want to read these words every day, so I made myself a nice looking page for them.

Source: [Porkbeard](https://twitter.com/Porkbeard/status/296920453442842625)

