# Vertical Left and Right Timeline

A Pen created on CodePen.io. Original URL: [https://codepen.io/cplepage/pen/EozVXL](https://codepen.io/cplepage/pen/EozVXL).

Vertical timeline going from left to right